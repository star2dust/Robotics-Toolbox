%HAL Human Arm-like subclass for SerialLink
%
% A class to model the kinematics of the human right arm and human 
% arm-like robots. Is a subclass of the SerialLink class, developed by 
% Peter Corke (www.petercorke.com). See help folder for figure of HAL
% chain frames.
% 
% Copyright (C) Bryan Moutrie, 2013-2014
% Licensed under the GNU General Public License, see file for statement
%
% This file modifies file(s) from The Robotics Toolbox for MATLAB (RTB)
% by Peter Corke (www.petercorke.com), see file for statement
%
% Syntax:
%  (1) hal = HAL(Tg, gre, erw, g)
%  (2) hal = HAL()
%
%  (2) is as per (1) but uses default values:
%       Tg = trotx(pi/2);
%       gre = from anthroData
%       erw = from anthroData
%       g = [-0.2; 0.1; 0.2];
%
% Outputs:
%  hal : Returned HAL object
%
% Inputs:
%  Tg  : Coordinate frame of the shoulder
%  gre : Length of the upper arm
%  erw : Length of the forearm
%  g   : Goal vector
%
% See also anthroData SerialLink

% LICENSE STATEMENT:
%
% This file is part of pHRIWARE.
% 
% pHRIWARE is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% pHRIWARE is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with pHRIWARE.  If not, see <http://www.gnu.org/licenses/>.
%
% RTB LIBRARY:
%
% Copyright (C) 1993-2014, by Peter I. Corke
% http://www.petercorke.com
% Released under the GNU Lesser General Public license,
% Modified 15/6/2014 (HAL is a subclass of SerialLink)

classdef HAL < SerialLink

    properties (Dependent)
        AP % Arm properties (Tg, gre, erw, g)
    end
    
    properties
        goal % Elbow axis normal vector, for resolving swivel angle
    end
    
    methods
        function hal = HAL(Tg, gre, erw, g)
   
            if ~nargin
                [~, gre, erw] = anthroData('gre', 'erw');
                Tg = trotx(pi/2);
                g = [-0.2; 0.1; 0.2];
            end
            
            wrh = 0; % Hand length, make non-zero in future version
            
            % Adduction/abduction
            L(1) = Revolute('alpha', -pi/2, 'offset', -pi/2,...
                'qlim', [-30 180]*d2r);
            % Extension/flexion
            L(2) = Revolute('alpha', -pi/2, 'offset', -pi/2,...
                'qlim', [-60 180]*d2r);
            % External/internal rotation
            L(3) = Revolute('d', gre, 'alpha', -pi/2, 'offset', pi,...
                'qlim', [-90 60]*d2r);
            % Extension/flexion
            L(4) = Revolute('a', erw,...
                'qlim', [-90 60]*d2r);
            % Ulnar/radial deviation
            L(5) = Revolute('alpha', pi/2,...
                'qlim', [-30 20]*d2r);
            % Extension/flexion
            L(6) = Revolute('alpha', -pi/2, 'offset', pi/2,...
                'qlim', [-80 60]*d2r);
            % Pronation/supination
            L(7) = Revolute('d', -wrh,...
                'qlim', [-80 80]*d2r);
            
            hal = hal@SerialLink(L, 'base', Tg,...
                'tool', troty(pi/2),...
                'name', 'Right Arm',...
                'comment', 'Kinematic model of the human right arm',...
                'ikine', 'RightArm');
            
            hal.manuf = '(C) Bryan Moutrie 2014';
            
            hal.goal = g;
            
            n = 50;
            Upoints = [zeros(1,n); linspace(0,2*gre/3,n); zeros(1,n)]';
            % Only 2/3 towards shoulder to not get caught
            Fpoints = [linspace(0,-erw,n); zeros(2,n)]';
            hal.points = {[], [], Upoints, Fpoints, [], [], []};
            hal.faces = cell(1,7);
        end
        
        function AP = get.AP(hal)
            AP = {hal.base, hal.d(3), hal.a(4), hal.goal};
        end
        
        function [q1, q2] = gikine(hal, Tu)
           %GIKINE Shoulder inverse kinematics of HAL right shoulder
           %
           % Wrapper function for HAL objects
           % (HAL.base replaces Tg)
           %
           % See also gikine
           
           [q1, q2] = gikine(hal.base, Tu);
        end
        
        function [Tf, Ts, Tu] = h2fsu(hal, varargin)
           %H2FSU Convert hand data to forearm, swivel, and upper arm frames
           %
           % Wrapper function for HAL objects
           % (HAL.AP replaces AP)
           %
           % See also h2fsu
           
           [Tf, Ts, Tu] = h2fsu(hal.AP, varargin{:});
        end
        
        function [q1, q2] = wikine(hal, varargin) %#ok<INUSL>
           %WIKINE Wrist inverse kinematics of HAL-like right wrist
           %
           % Wrapper function for HAL objects
           % (HAL is not used)
           %
           % See also wikine
           
           warning('wikine does not use a HAL object!');
           [q1, q2] = wikine(varargin{:});
        end
    end
    
end

