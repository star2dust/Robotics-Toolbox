%REACHABLE Find if a pose is reachable
%
% Tests if a pose, described by two sets of joint angles (such as that
% from ikine), is reachable or not. Will output the permutation of the
% two sets, which is reachable.
%
% Copyright (C) Bryan Moutrie, 2013-2014
% Licensed under the GNU General Public License, see file for statement
%
% This file modifies file(s) from The Robotics Toolbox for MATLAB (RTB)
% by Peter Corke (www.petercorke.com), see file for statement
%
% Syntax:
%  (1) q = hal.reachable(q1, q2)
%  (2) q = hal.reachable(Th, phi)
%  (3) q = hal.reachable(Th)
%  (4) [q, u] = hal.reachable(...)
%
%  (2) and (3) is as per (1) but calls ikine to get q1 and q2
%  (4) is as per (1)-(3) but with vector marking unreachable poses
%
% Outputs:
%  q :  HAL joint angles. Each row is a pose and may contain parts of
%       q1 and q2, depending if they are within limits. If the pose is
%       not reachable, that row is NaN
%  u  : Vector which is equal to any(isnan(q),2). I.e, elements are
%       true if that row of q is unreachable
%
% Inputs:
%  q1  : HAL joint angles - first family of solutions
%  q2  : HAL joint angles - Second family of solutions
%  Th  : Hand frame(s) (4x4x...)
%  phi : Swivel angle,
%        (0) 0     : Uses phi = 0
%        (1)       : Uses the z-axis of Tw for the z-axis of Ts, via
%                     projection
%        (2) 'h2g' : Is the hand-2-goal method, s.t. z-axis of Ts is 
%                     the cross product of the swivel axis and g
%        (3) step  : step is a scalar >0 so that the swivel angle
%                      is added as an an extra dimension, with phi = 
%                      median human range +/- step increments up to the
%                      human limits. The swivel angle increases with 
%                      the increasing index of the extra dimension.
%        (4) PHI   : PHI uses an explicit value, the number of elements
%                     in PHI must be a multiple of the number of hand 
%                     points/frames
%
% See also HAL.h2fsu HAL.ikine HAL.islimit

% LICENSE STATEMENT:
%
% This file is part of pHRIWARE.
% 
% pHRIWARE is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% pHRIWARE is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with pHRIWARE.  If not, see <http://www.gnu.org/licenses/>.
%
% RTB LIBRARY:
%
% Copyright (C) 1993-2014, by Peter I. Corke
% http://www.petercorke.com
% Released under the GNU Lesser General Public license,
% Modified 16/6/2014 (HAL is a subclass of SerialLink)

function [q, u] = reachable(hal, varargin)

if length(varargin) == 1 || ...
        ~isequal(size(varargin{1},2),size(varargin{2},2),7)
    [q1, q2] = hal.ikine(varargin{1});
else
    q1 = varargin{1};
    q2 = varargin{2};
end


q = NaN(size(q1));
  
I1 = hal.islimit(q1);
I2 = hal.islimit(q2);

q1g = all(~I1(:,1:3),2);
q2g = all(~I2(:,1:3),2);

q1e = all(~I1(:,4),2);
q2e = all(~I2(:,4),2);

q1w = all(~I1(:,5:7),2);
q2w = all(~I2(:,5:7),2);

q(q2g,1:3) = q2(q2g,1:3);
q(q1g,1:3) = q1(q1g,1:3);

q(q1e,4) = q1(q1e,4);

q(q2w,5:7) = q2(q2w,5:7);
q(q1w,5:7) = q1(q1w,5:7);

u = any(isnan(q),2);

q(u,:) = NaN;

end

