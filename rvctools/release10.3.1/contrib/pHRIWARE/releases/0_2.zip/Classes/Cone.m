classdef Cone < Curvilinear
    %UNTITLED2 Summary of this class goes here
    %   Detailed explanation goes here

    methods
        function s = Cone(T, S, varargin)
            if ~nargin
               T = [];
               S = [];
            end
            
            p = @(t)(1-t);
            
            if numel(S) == 2, S = [S(1), S]; end
            
            coneDefaults = [{'n',2,'faces',[1 0]}, varargin];
            s = s@Curvilinear(T,S,p,coneDefaults{:});
        end
    end
end
