%%begin
% In this demo, we are testing for collisions in a situation where a
% person is moving their arm about randomly  while a PUMA 560 robot
% also moves about randomly.

% We will load a saved SerialLink model of a PUMA 560 with STL data:
load('p560_col.mat');
p560

% We will now load the CollisionModels for our person
arm = cmdl_arm();
x = 1/sqrt(2);
Tg = [x 0 -x 0; -x 0 -x 0.3; 0 1 0 0.6; 0 0 0 1];
hat = cmdl_hat(Tg);

% Let's see what we have
fig1 = figure;
p560.plot3d(zeros(1,6));
hold on
hat.plot;

% The arm is not shown for now, and we are not considering the person's
% legs.

% Both robot and human have a 3-DOF wrist which do not affect the
% occupied space of their arms - we will keep these zero for simplicity
q_560 = [2*pi*rand(20,3), zeros(20,3)];
q_man = [2*pi*rand(20,4), zeros(20,3)];

% We will ignore joint limits of both for this demo

% We need to get the coordinate frames of the upper arm and forearm of
% the person for all 20 time steps. One way to do this is to use the
% HAL class and h2fsu method:
hal = HAL();
hal.base = Tg;
Th = hal.fkine(q_man);
[Tf, ~, Tu] = hal.h2fsu(Th);

% Because the wrist is neutral, we do not have to worry about setting a
% method to resolve the swivel angle. We use the MATLAB function cat to
% concatenate Tf and Tu for the collisions method. In the arm
% CollisionModel, the upper arm is the first primitive, so we do:
dyn_T = cat(4, Tu, Tf);
size(dyn_T)

% We check for collisions then by:

c = p560.collisions(q_560, hat, arm, dyn_T)

% Let's inspect the first colliding result
% (If there happens to be no collisions, brace yourself for an error -
% sorry! Try running the demo again

i = find(c, 1, 'first');
close(fig1); figure;
p560.plot3d(q_560(i,:));
hold on
hal.plot(q_man(i,:));
    