%%begin
% We will begin by constructing a HAL object with default properties

hal = HAL()

% Let's plot it in the zero angle configuration
qz = zeros(1,7);
hal.plot(qz); campos([6.5 6 5]);

% Note with a neutral wrist, the x-axis is in the direction of the
% forearm, and the z-axis is the elbow axis.

close;
% We can see already that as a subclass, HAL inherits lots of 
% functionality SerialLink objects. Forward kinematics is the same too
T = hal.fkine(qz)

% Methods that are overloaded are ikine and islimit. Check out the help
% or doc files for these methods.
%
% Extending ikine also is the method reachable, which combines the two
% inverse kinematic solutions
q = hal.reachable(T)

% You can use the method h2fsu to convert hand points into forearm
% frames, which, if the wrist is in the neutral position, is also the
% hand frame

T = hal.h2fsu(T(1:3,4), 'h2g')

% h2fsu in this case has used the hand-to-goal method of resolving the
% swivel angle. The elbow axis is made perpendicular to the goal vector
hal.goal
dot(hal.goal, T(1:3,3))
% The dot product is near-zero which says they are perpendicular.

% Let's see what it looks like
q = hal.reachable(T, 'h2g');
hal.plot(q); campos([6.5 6 5]);

